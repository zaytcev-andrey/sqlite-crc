Here goes the libraries (both static and shared) for this component.
This readme has the main purpose to avoid that CVS clients prune the LIB folder.
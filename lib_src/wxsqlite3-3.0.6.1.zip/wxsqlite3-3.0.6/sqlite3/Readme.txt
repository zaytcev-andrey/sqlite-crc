This directory contains all SQLite3 version 3.8.2 files needed on Windows platforms.
For the version with encryption support (AES-128 or AES-256) the SQLite amalgamation source code is included.
The source code of the SQLite extension function module is included, too.

This directory contains the files belonging to the SQLite3 encryption
extension provided by wxSQLite3.

There is now support for Premake (http://industriousone.com/premake).
Premake 4.4-beta3 or higher is required.

Precompiled DLLs are provided for Windows. They are located in the
subdirectory aes128/dll/release resp. aes128/dll/release.

Precompiled SQLite3 shells are also provided for Windows. They are
located in the subdirectory aes128/lib/release resp. aes128/lib/release.
